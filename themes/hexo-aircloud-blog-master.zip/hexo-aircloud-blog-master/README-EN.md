## Hexo-Aircloud-Blog: A DEMO For [Hexo-Theme-AirCloud](https://github.com/aircloud/hexo-theme-aircloud)

> [中文文档](./README.md) | [LIVE PRIVIEW](http://niexiaotao.cn/)

## Usage

Need to install hexo globally before

```
git clone https://github.com/aircloud/hexo-theme-aircloud.git
cd hexo-theme-aircloud
npm install
hexo serve
```

Then visit http://localhost:4000/

## Configuration

Directly update _config.yml. If you have some problems, please create an issue [there](https://github.com/aircloud/hexo-aircloud-blog/issues)

> Continuous updating